const $=s=>document.querySelector(s),root=$('#simple-plug');
const grid=$('.grid'),picker=$('.channel'),feedback=$('.feedback');
let serverOrigin=localStorage.getItem('plug-origin')||'',token=sessionStorage.getItem('plug-token')||'',data=null,online=false,busy=false,pollHandle,toastHandle,pollBusy=false,publicControl=true;
const blank=()=>Array.from({length:4},(_,i)=>({name:'ช่อง '+(i+1),emoji:['💡','🔌','🌀','🌿'][i],on:false,daily:false,onMinute:480,offMinute:1080,remaining:0,target:false}));
let channels=blank();
let lastKnownSeen=Number(localStorage.getItem('plug-last-seen:'+location.origin))||null;
let eventSocket=null,eventRetry=null,lastSnapshotTick=0;
const statusDetail=document.createElement('div');statusDetail.className='muted last-seen';statusDetail.style.cssText='margin:-12px 0 20px;line-height:1.7';$('.top-status').after(statusDetail);
function lastSeenText(at){return at?'ได้รับสัญญาณจากบอร์ดล่าสุด: '+new Intl.DateTimeFormat('th-TH',{timeZone:'Asia/Bangkok',dateStyle:'short',timeStyle:'medium'}).format(new Date(at))+' น.':'ยังไม่ได้รับสัญญาณจากบอร์ด';}
function connectEvents(){
 if(document.hidden)return;
 if(eventSocket&&[WebSocket.CONNECTING,WebSocket.OPEN].includes(eventSocket.readyState))return;
 const url=new URL('/api/events',serverOrigin);url.protocol=url.protocol==='https:'?'wss:':'ws:';
 eventSocket=new WebSocket(url);
 eventSocket.onmessage=e=>{try{const d=JSON.parse(e.data);if(typeof d.online==='boolean')applyState(d);}catch{}};
 eventSocket.onclose=()=>{clearTimeout(eventRetry);eventRetry=setTimeout(connectEvents,3000);};
 eventSocket.onerror=()=>eventSocket.close();
}
function checkFreshness(){
 if(!data||!online)return;
 const ttl=data.offlineAfterMs||10000;
 const age=(data.serverNow-(data.lastSeenAt||data.confirmedAt||0))+(performance.now()-lastSnapshotTick);
 if(age>=ttl){online=false;render();$('.connection').textContent='○ บอร์ดออฟไลน์';$('.connection').classList.add('offline');$('.all').disabled=true;}
}
setInterval(checkFreshness,1000);

function page(name){root.querySelectorAll('.panel').forEach(p=>p.hidden=p.id!=='simple-'+name+'-panel');root.querySelectorAll('[data-page]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.page===name)));}
function toast(message){clearTimeout(toastHandle);$('.success-text').textContent=message;$('.success').hidden=false;toastHandle=setTimeout(()=>$('.success').hidden=true,3000);}
function timeText(m){return String(Math.floor(m/60)).padStart(2,'0')+':'+String(m%60).padStart(2,'0');}
function minute(s){const [h,m]=s.split(':').map(Number);return h*60+m;}
async function request(path,body){const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),12000);try{const r=await fetch(serverOrigin+path,{cache:'no-store',signal:controller.signal,headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...(body!==undefined?{method:'POST',body:JSON.stringify(body)}:{})});const d=await r.json();if(!r.ok){if(r.status===401&&path!=='/api/login'&&!publicControl)logout();throw Error(d.error||'ติดต่อระบบไม่ได้');}return d;}catch(e){if(e.name==='AbortError')throw Error('ติดต่อระบบไม่สำเร็จ กรุณาลองใหม่');throw e;}finally{clearTimeout(timeout);}}
function applyState(d){data=d;lastSnapshotTick=performance.now();online=d.online===true;const seen=d.lastSeenAt||d.confirmedAt;if(Number.isFinite(seen)&&seen>(lastKnownSeen||0)){lastKnownSeen=seen;try{localStorage.setItem('plug-last-seen:'+location.origin,String(seen));}catch{}}statusDetail.textContent=lastSeenText(lastKnownSeen);const editing=!$('#simple-schedule-panel').hidden;if(d.state)channels=d.state.channels;render();$('.connection').textContent=online?(d.state.clockValid?'● บอร์ดออนไลน์':'● บอร์ดออนไลน์ · ยังไม่พร้อมตั้งเวลารายวัน'):'○ บอร์ดออฟไลน์';$('.connection').classList.toggle('offline',!online);$('.all').disabled=!online||busy;if(!editing)updatePicker();}
function updatePicker(){const previous=picker.value;picker.replaceChildren(...channels.map((c,i)=>new Option(c.name,String(i))));picker.value=previous||'0';}
function render(){grid.replaceChildren();channels.forEach((c,i)=>{const tile=document.createElement('article');tile.className='tile'+(online&&c.on?' active':'');tile.innerHTML='<div class="tile-top"><button class="emoji-edit" type="button"></button><button class="power" type="button"></button></div><button class="name-edit" type="button"></button><div class="state" role="status"></div><button class="schedule-link" type="button"><span class="schedule-text"></span><span aria-hidden="true">›</span></button>';tile.querySelector('.emoji-edit').textContent=c.emoji;tile.querySelector('.emoji-edit').setAttribute('aria-label','แก้อีโมจิ '+c.name);tile.querySelector('.name-edit').textContent=c.name;tile.querySelector('.name-edit').setAttribute('aria-label','แก้ชื่อ '+c.name);const power=tile.querySelector('.power');power.setAttribute('aria-label','เปิดปิด '+c.name);power.setAttribute('aria-pressed',String(online&&c.on));power.setAttribute('aria-busy',String(busy));power.disabled=busy||!online;power.onclick=()=>command('relay',{channel:i,on:c.on?0:1});tile.querySelector('.state').textContent=online?(c.on?'เปิด':'ปิด'):'—';tile.querySelector('.schedule-text').textContent=c.remaining>0?'อีก '+Math.ceil(c.remaining/60)+' นาที':timeText(c.onMinute)+'–'+timeText(c.offMinute)+(c.daily?' · ทุกวัน':' · พักไว้');const edit=()=>{picker.value=String(i);load();page('schedule');};tile.querySelector('.name-edit').onclick=edit;tile.querySelector('.emoji-edit').onclick=edit;tile.querySelector('.schedule-link').onclick=edit;grid.appendChild(tile);});}
function load(){const c=channels[Number(picker.value)];$('.channel-name').value=c.name;$('.channel-emoji').value=c.emoji;$('.enabled').checked=c.daily;$('.open-time').value=timeText(c.onMinute);$('.close-time').value=timeText(c.offMinute);$('.minutes').value=c.remaining>0?Math.ceil(c.remaining/60):30;$('.action').value=c.target?'on':'off';$('.timer-result').textContent=c.remaining>0?'เหลือประมาณ '+Math.ceil(c.remaining/60)+' นาที':'ไม่มีนับถอยหลัง';$('.cancel').hidden=!(c.remaining>0);}
function lock(value){busy=value;document.querySelectorAll('.editor button,.editor input,.editor select').forEach(b=>b.disabled=value);render();$('.all').disabled=value||!online;}
async function command(action,payload,onSaved=false){if(busy)return;if(!online){toast('บอร์ดออฟไลน์ ยังส่งคำสั่งไม่ได้');return;}lock(true);feedback.textContent='';try{const {id}=await request('/api/command',{action,payload});const deadline=Date.now()+13000;let confirmed=false;while(Date.now()<deadline){await new Promise(r=>setTimeout(r,350));const d=await request('/api/state?command='+encodeURIComponent(id));applyState(d);if(d.command?.status==='done'){confirmed=true;break;}if(['failed','timeout'].includes(d.command?.status))throw Error(d.command.error||'ไม่ได้รับการยืนยันจากบอร์ด');if(!d.online)throw Error('การเชื่อมต่อบอร์ดขาด ยังยืนยันคำสั่งไม่ได้');}if(!confirmed)throw Error('บอร์ดไม่ตอบกลับ กรุณาตรวจสถานะก่อนสั่งใหม่');if(onSaved){page('devices');toast('✓ บันทึกสำเร็จ');}}catch(e){toast(e.message);try{applyState(await request('/api/state'));}catch{online=false;render();$('.connection').textContent='ติดต่อระบบไม่ได้';}}finally{lock(false);}}
function configBase(){const c=channels[Number(picker.value)];return {channel:Number(picker.value),name:c.name,emoji:c.emoji,daily:c.daily?1:0,onMinute:c.onMinute,offMinute:c.offMinute,minutes:c.remaining>0?Math.ceil(c.remaining/60):0,target:c.target?1:0};}
$('.identity').onsubmit=e=>{e.preventDefault();const p=configBase();p.name=$('.channel-name').value.trim();p.emoji=$('.channel-emoji').value.trim();if(!p.name){toast('กรอกชื่อช่องก่อนบันทึก');return;}if(new TextEncoder().encode(p.name).length>80||new TextEncoder().encode(p.emoji).length>32){toast('ชื่อหรืออีโมจิยาวเกินไป');return;}command('config',p,true);};
$('.daily').onsubmit=e=>{e.preventDefault();const p=configBase();p.daily=$('.enabled').checked?1:0;if(p.daily&&!data?.state?.clockValid){toast('บอร์ดยังไม่พร้อมตั้งเวลา รอซิงก์เวลาก่อน');return;}p.onMinute=minute($('.open-time').value);p.offMinute=minute($('.close-time').value);if(p.daily&&p.onMinute===p.offMinute){toast('เวลาเปิดและปิดต้องต่างกัน');return;}command('config',p,true);};
$('.countdown').onsubmit=e=>{e.preventDefault();const p=configBase();p.minutes=Number($('.minutes').value);p.target=$('.action').value==='on'?1:0;if(!Number.isInteger(p.minutes)||p.minutes<1||p.minutes>10080){toast('ระบุเวลา 1–10080 นาที');return;}command('config',p,true);};
$('.cancel').onclick=()=>command('config',{...configBase(),minutes:0},true);
root.querySelectorAll('[data-emoji]').forEach(b=>b.onclick=()=>$('.channel-emoji').value=b.dataset.emoji);
root.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>{page(b.dataset.page);if(b.dataset.page==='schedule'){updatePicker();load();}});picker.onchange=load;$('.all').onclick=()=>command('all-off',{});
async function poll(){if(busy||pollBusy||(!publicControl&&!token)||document.hidden)return;pollBusy=true;try{applyState(await request('/api/state'));}catch{online=false;$('.connection').textContent='ติดต่อระบบไม่ได้';render();$('.all').disabled=true;}finally{pollBusy=false;}}
function start(){clearInterval(pollHandle);$('#setup').hidden=true;$('.app').hidden=false;poll();connectEvents();pollHandle=setInterval(poll,5000);}
function logout(){token='';sessionStorage.removeItem('plug-token');clearInterval(pollHandle);$('#setup').hidden=false;$('.app').hidden=true;online=false;}
$('#logout').onclick=logout;
$('#setup-form').onsubmit=async e=>{e.preventDefault();const button=$('#connect');button.disabled=true;$('#setup-error').textContent='';try{const typed=$('#worker-url').value.trim();const u=new URL(typed);if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||u.pathname!=='/')throw Error('ใช้ URL HTTPS ของ Worker เช่น https://smart-plug.ชื่อบัญชี.workers.dev');serverOrigin=u.origin;const d=await request('/api/login',{password:$('#password').value});token=d.token;sessionStorage.setItem('plug-token',token);localStorage.setItem('plug-origin',serverOrigin);$('#password').value='';start();}catch(e){$('#setup-error').textContent=e.message;}finally{button.disabled=false;}};
$('#worker-url').value=serverOrigin||(/\.workers\.dev$/.test(location.hostname)?location.origin:'');
render();updatePicker();
serverOrigin=location.origin;
$('#logout').hidden=true;
start();
document.addEventListener('visibilitychange',()=>{if(!document.hidden){checkFreshness();poll();connectEvents();}});

